import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Role } from '../../common/constants/roles.enum';
import { Student } from '../students/entities/student.entity';
import { Teacher } from '../teachers/entities/teacher.entity';
import { CourseSection } from '../course-sections/entities/course-section.entity';
import { Enrollment } from './entities/enrollment.entity';

interface AuthenticatedUser {
  id: number;
  role: Role;
}

@Injectable()
export class EnrollmentsService {
  constructor(
    @InjectRepository(Enrollment)
    private readonly repo: Repository<Enrollment>,
    @InjectRepository(Student)
    private readonly studentsRepo: Repository<Student>,
    @InjectRepository(Teacher)
    private readonly teachersRepo: Repository<Teacher>,
    @InjectRepository(CourseSection)
    private readonly sectionsRepo: Repository<CourseSection>,
  ) {}

  async findAll(user: AuthenticatedUser) {
    if (user.role === Role.STUDENT) {
      const student = await this.studentsRepo.findOne({ where: { userId: user.id } });
      if (!student) throw new NotFoundException('Student profile not found for this account');
      return this.repo.find({ where: { studentId: student.id }, order: { id: 'ASC' } });
    }
    if (user.role === Role.TEACHER) {
      const teacher = await this.teachersRepo.findOne({ where: { userId: user.id } });
      if (!teacher) throw new NotFoundException('Teacher profile not found for this account');
      const sections = await this.sectionsRepo.find({ where: { teacherId: teacher.id } });
      const sectionIds = sections.map(({ id }) => id);
      return sectionIds.length
        ? this.repo.find({ where: { courseSectionId: In(sectionIds) }, order: { id: 'ASC' } })
        : [];
    }
    return this.repo.find({ order: { id: 'ASC' } });
  }

  async findOne(id: number, user: AuthenticatedUser) {
    const e = await this.repo.findOne({ where: { id } });
    if (!e) throw new NotFoundException(`Enrollment #${id} not found`);
    await this.assertCanAccess(e, user);
    return e;
  }

  async create(data: Partial<Enrollment>, user: AuthenticatedUser) {
    if (user.role === Role.STUDENT) {
      if (!data.courseSectionId) throw new BadRequestException('Select a course section.');
      const student = await this.studentsRepo.findOne({ where: { userId: user.id } });
      if (!student) throw new NotFoundException('Student profile not found for this account');
      const section = await this.sectionsRepo.findOne({ where: { id: data.courseSectionId } });
      if (!section) throw new NotFoundException(`Course section #${data.courseSectionId} not found`);
      if (section.status !== 'open') throw new BadRequestException('This course section is not open for enrollment.');
      if (section.enrolledCount >= section.capacity) throw new BadRequestException('This course section is full.');
      const existing = await this.repo.findOne({
        where: {
          studentId: student.id,
          courseSectionId: section.id,
          status: In(['pending', 'approved']),
        },
      });
      if (existing) throw new ConflictException('You already have an active enrollment for this course section.');
      return this.repo.save(this.repo.create({
        studentId: student.id,
        courseSectionId: section.id,
        semesterId: section.semesterId,
        status: 'pending',
      }));
    }
    return this.repo.save(this.repo.create(data));
  }

  async update(id: number, data: Partial<Enrollment>, user: AuthenticatedUser) {
    const enrollment = await this.findOne(id, user);
    await this.repo.update(id, {
      status: data.status ?? enrollment.status,
      approvedBy: data.approvedBy ?? enrollment.approvedBy,
      approvedAt: data.approvedAt ?? enrollment.approvedAt,
    });
    return this.findOne(id, user);
  }

  async remove(id: number, user: AuthenticatedUser) {
    await this.findOne(id, user);
    await this.repo.delete(id);
    return { message: `Enrollment #${id} deleted` };
  }

  private async assertCanAccess(enrollment: Enrollment, user: AuthenticatedUser) {
    if (user.role === Role.STUDENT) {
      const student = await this.studentsRepo.findOne({ where: { userId: user.id } });
      if (!student) throw new NotFoundException('Student profile not found for this account');
      if (enrollment.studentId !== student.id) throw new ForbiddenException();
    } else if (user.role === Role.TEACHER) {
      const teacher = await this.teachersRepo.findOne({ where: { userId: user.id } });
      if (!teacher) throw new NotFoundException('Teacher profile not found for this account');
      const section = await this.sectionsRepo.findOne({
        where: { id: enrollment.courseSectionId, teacherId: teacher.id },
      });
      if (!section) throw new ForbiddenException();
    }
  }
}