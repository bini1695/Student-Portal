import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Role } from '../../common/constants/roles.enum';
import { Teacher } from '../teachers/entities/teacher.entity';
import { CourseSection } from './entities/course-section.entity';

interface AuthenticatedUser {
  id: number;
  role: Role;
}

@Injectable()
export class CourseSectionsService {
  constructor(
    @InjectRepository(CourseSection) private readonly repo: Repository<CourseSection>,
    @InjectRepository(Teacher) private readonly teachersRepo: Repository<Teacher>,
  ) {}

  async findAll(user: AuthenticatedUser) {
    if (user.role === Role.STUDENT) {
      return this.repo.find({ where: { status: 'open' }, order: { id: 'ASC' } });
    }
    if (user.role === Role.TEACHER) {
      const teacher = await this.teachersRepo.findOne({ where: { userId: user.id } });
      if (!teacher) throw new NotFoundException('Teacher profile not found for this account');
      return this.repo.find({ where: { teacherId: teacher.id }, order: { id: 'ASC' } });
    }
    return this.repo.find({ order: { id: 'ASC' } });
  }

  async findOne(id: number, user: AuthenticatedUser) {
    const s = await this.repo.findOne({ where: { id } });
    if (!s) throw new NotFoundException(`CourseSection #${id} not found`);
    if (user.role === Role.STUDENT && s.status !== 'open') throw new ForbiddenException();
    if (user.role === Role.TEACHER) {
      const teacher = await this.teachersRepo.findOne({ where: { userId: user.id } });
      if (!teacher) throw new NotFoundException('Teacher profile not found for this account');
      if (s.teacherId !== teacher.id) throw new ForbiddenException();
    }
    return s;
  }

  create(data: Partial<CourseSection>) { return this.repo.save(this.repo.create(data)); }

  async update(id: number, data: Partial<CourseSection>, user: AuthenticatedUser) {
    await this.findOne(id, user);
    await this.repo.update(id, data);
    return this.repo.findOneByOrFail({ id });
  }

  async remove(id: number, user: AuthenticatedUser) {
    await this.findOne(id, user);
    await this.repo.delete(id);
    return { message: `CourseSection #${id} deleted` };
  }
}